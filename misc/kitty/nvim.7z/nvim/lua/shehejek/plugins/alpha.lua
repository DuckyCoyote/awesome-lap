return {
	'goolord/alpha-nvim',
	lazy = false
}
