return
{
	'nvim-lualine/lualine.nvim',
	lazy = true,
}
