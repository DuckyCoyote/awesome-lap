vim.g.mapleader = " "

require("shehejek.lazy")
require("shehejek.keymaps")
require("shehejek.opts")
require("shehejek.configs")
